package com.aylien.secretsantamanager.service;

import com.aylien.secretsantamanager.domain.SecretSantaResult;

public interface SecretSantaService {
	SecretSantaResult createList(int year);
}
