package com.aylien.secretsantamanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecretSantaManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecretSantaManagerApplication.class, args);
	}

}
