package com.aylien.secretsantamanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecretSantaManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
